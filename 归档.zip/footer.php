﻿<!--王庆路 资源文件的路径进行了更改-->
<div class="btm_bg">
	<div class="btm"><span>加入 <?php echo $title; ?> 立刻使用新闻稿发布平台！</span> <a target="_blank" rel="nofollow"
	                                                                       href="../reg.php"><img
				src="/huo15template/img/btn_ljjr.jpg" alt="注册账号" width="236" height="40"
				style="display:block; float:right; margin-top:13px;"></a></div>
</div>
<!--王庆路 全局变量qq1 qq2 qq3 qq4 qq5和kefu1 kefu2 kefu3 kefu4 kefu5-->
<script>
	qq1 = "<?php echo $qq?>";
	qq2 = "<?php echo $qq2?>";
	qq3 = "<?php echo $qq3?>";
	qq4 = "<?php echo $qq4?>";
	qq5 = "<?php echo $qq5?>";
	kefu1 = "总客服";
	kefu2 = "<?php echo $kefu2?>";
	kefu3 = "<?php echo $kefu3?>";
	kefu4 = "<?php echo $kefu4?>";
	kefu5 = "<?php echo $kefu5?>";
</script>
<script src='/huo15template/js/ServiceQQ.js'></script>
<!--王庆路 全局变量qq1 qq2 qq3 qq4 qq5和kefu1 kefu2 kefu3 kefu4 kefu5 end-->
<div class="footer com_bg">
	<div class="wrapper">
		<div class="row_08">
			<div class="box1">
				<div class="head">
					<h3>商务合作</h3>
				</div>
				<div class="body">
					<ul>
						<li>企业QQ：<?php echo $qq; ?></li>
						<li>咨询电话：<?php echo $dianhua; ?></li>
						<li>售后电话：<?php echo $dianhua; ?></li>
						<li>投诉电话：<?php echo $dianhua; ?></li>
					</ul>
				</div>
			</div>
			<!--box1 end-->
			<div class="box2">
				<div class="head">
					<h3>服务咨询</h3>
				</div>
				<div class="body">
					<ul>
						<!--王庆路 更改QQ 客服昵称输出-->
						<li>总客服：<?php echo $qq; ?>（售前）<a target="_blank" rel="nofollow"
						                         href="http://wpa.qq.com/msgrd?v=3&amp;uin=<?php echo $qq; ?>&amp;site=qq&amp;menu=yes"><img
									border="0" src="http://pub.idqqimg.com/qconn/wpa/button/button_121.gif"
									alt="点击这里给我发消息" title="点击这里给我发消息"></a></li>
						<li><?php echo $kefu2 ?>：<?php echo $qq2 ?>（售前）<a target="_blank" rel="nofollow"
						                         href="http://wpa.qq.com/msgrd?v=3&amp;uin=<?php echo $qq2 ?>&amp;site=qq&amp;menu=yes"><img
									border="0" src="http://pub.idqqimg.com/qconn/wpa/button/button_121.gif"
									alt="点击这里给我发消息" title="点击这里给我发消息"></a></li>
						<li><?php echo $kefu3 ?>：<?php echo $qq3 ?>（售前）<a target="_blank" rel="nofollow"
						                                          href="http://wpa.qq.com/msgrd?v=3&amp;uin=<?php echo $qq3 ?>&amp;site=qq&amp;menu=yes"><img
									border="0" src="http://pub.idqqimg.com/qconn/wpa/button/button_121.gif"
									alt="点击这里给我发消息" title="点击这里给我发消息"></a></li>
						<li><?php echo $kefu4 ?>：<?php echo $qq4 ?>（售后）<a target="_blank" rel="nofollow"
						                         href="http://wpa.qq.com/msgrd?v=3&amp;uin=<?php echo $qq4 ?>&amp;site=qq&amp;menu=yes"><img
									border="0" src="http://pub.idqqimg.com/qconn/wpa/button/button_121.gif"
									alt="点击这里给我发消息" title="点击这里给我发消息"></a></li>
						<li><?php echo $kefu5 ?>：<?php echo $qq5 ?>（售后）<a target="_blank" rel="nofollow"
						                         href="http://wpa.qq.com/msgrd?v=3&amp;uin=<?php echo $qq5 ?>&amp;site=qq&amp;menu=yes"><img
									border="0" src="http://pub.idqqimg.com/qconn/wpa/button/button_121.gif"
									alt="点击这里给我发消息" title="点击这里给我发消息"></a></li>
						<!--王庆路 更改QQ end-->
					</ul>
				</div>
			</div>
			<!--box2 end-->
			<div class="box3">
				<div class="head">
					<h3>联系我们</h3>
				</div>
				<div class="body">
					<ul>

						<li>微信： mingzhi103 (经理微信号)</li>
						<li>地址：山东省青岛市市北区山东路182号9栋</li>
					</ul>
				</div>
			</div>
			<!--box3 end-->
			<div class="box4">
				<div class="head">
					<h3>扫一扫 加关注</h3>
				</div>
				<div class="body"><img src="/huo15template/img/rwztcWechat.png" style="width: 140px; height: 140px;"
				                       alt=""></div>
			</div>
			<!--box4 end-->
			<div class="clear"></div>
		</div>
	</div>
	<!--row_08 end-->
	<div class="copyright">
		<div class="thumb">
			<ul>
				<li><a rel="nofollow" target="_blank"
				       href="/"><img
							src="/huo15template/img/img74.gif"></a></li>
				<li><a rel="nofollow" target="_blank"
				       href="/"><img
							src="/huo15template/img/img75.gif"></a></li>
				<li><a rel="nofollow" target="_blank"
				       href="/"><img
							src="/huo15template/img/img76.gif"></a></li>
				<li><a rel="nofollow" target="_blank"
				       href="/"><img
							src="/huo15template/img/img77.png"></a></li>
			</ul>
		</div>
		<div class="foot_txt">
			<p><?php echo $title; ?>&nbsp;<a href="/">(Www.ruanwenztc.com)</a>&nbsp;&nbsp;© 2009-2016&nbsp;All Right
				Reserved.&nbsp;&nbsp; </p>
			<p>鲁ICP备12026404号-1 版权所有：青岛蔚蓝传媒 <a href="/"><strong>软文推广</strong></a>首选（<a
					href="/"><b><?php echo $title; ?></b></a>）新闻稿自助发布平台</p>
			<p><?php echo $title; ?>是国内信任的软文发布平台，隶属于青岛蔚蓝传媒，是您选择软文推广的首选服务商，<?php echo $title; ?>：老品牌、大影响、高效率、发遍全网络！</p>
			<p>
				<a target="_blank" href="http://www.huo15.com">技术支持：火一五信息科技</a>
			</p>
		</div>
		<div class="clear"></div>
	</div>
	<!--wrapper end-->
</div>
<!--王庆路 资源文件的路径进行了更改 end-->


