/*
 *	sGallery 1.0 - simple gallery with jQuery
 *	made by bujichong 2009-11-25
 *	���ߣ����  2009-11-25
 * http://hi.baidu.com/bujichong/
 *	��ӭ����ת�أ��������������Ͷ��ɹ������������Դ������
 */

(function ($) {
$.fn.sGallery = function (o) {
    return  new $sG(this, o);
			//alert('do');
    };

	var settings = {
		thumbObj:null,//Ԥ������
		titleObj:null,//����
		botLast:null,//��ť��һ��
		botNext:null,//��ť��һ��
		thumbNowClass:'now',//Ԥ������ǰ��class,Ĭ��Ϊnow
		slideTime:800,//ƽ������ʱ��
		autoChange:true,//�Ƿ��Զ��л�
		changeTime:5000,//�Զ��л�ʱ��
		delayTime:100//��꾭��ʱ��Ӧ���ӳ�ʱ��
	};

 $.sGalleryLong = function(e, o) {
    this.options = $.extend({}, settings, o || {});
	var _self = $(e);
	var set = this.options;
	var thumb;
	var size = _self.size();
	var nowIndex = 0; //����ȫ��ָ��
	var index;//����ȫ��ָ��
	var startRun;//Ԥ�����Զ����в���
	var delayRun;//Ԥ�����ӳ����в���

//��ʼ��
	_self.eq(0).show();

//���л�����
function fadeAB () {
	if (nowIndex != index) {
		if (set.thumbObj!=null) {
		$(set.thumbObj).removeClass().eq(index).addClass(set.thumbNowClass);}
		_self.eq(nowIndex).stop(false,true).fadeOut(set.slideTime);
		_self.eq(index).stop(true,true).fadeIn(set.slideTime);
		$(set.titleObj).eq(nowIndex).hide();//������title
		$(set.titleObj).eq(index).show();//������title
		nowIndex = index;
		if (set.autoChange==true) {
		clearInterval(startRun);//�����Զ��л�����
		startRun = setInterval(runNext,set.changeTime);}
		}
}

//�л�����һ��
function runNext() {
	index =  (nowIndex+1)%size;
	fadeAB();
}

//�����һͼƬ
	if (set.thumbObj!=null) {
	thumb = $(set.thumbObj);
//��ʼ��
	thumb.eq(0).addClass(set.thumbNowClass);
		thumb.bind("mousemove",function(event){
			index = thumb.index($(this));
			fadeAB();
			delayRun = setTimeout(fadeAB,set.delayTime);
			clearTimeout(delayRun);
			event.stopPropagation();
		})
	}

//�����һ��
	if (set.botNext!=null) {
		var botNext = $(set.botNext);
		botNext.mousemove(function () {
			runNext();
			return false;
		});
	}

//�����һ��
	if (set.botLast!=null) {
		var botLast = $(set.botLast);
		botLast.mousemove(function () {
			index = (nowIndex+size-1)%size;
			fadeAB();
			return false;
	});
	}

//�Զ�����
	if (set.autoChange==true) {
	startRun = setInterval(runNext,set.changeTime);
	}

}

var $sG = $.sGalleryLong;

})(jQuery);

function slide(Name,Class,Width,Height,fun){
	$(Name).width(Width);
	$(Name).height(Height);
	
	if(fun == true){
		$(Name).append('<div class="title-bg"></div><div class="title"></div><div class="change"></div>')
		var atr = $(Name+' div.changeDiv a');
		var sum = atr.length;
		for(i=1;i<=sum;i++){
			var title = atr.eq(i-1).attr("title");
			var href = atr.eq(i-1).attr("href");
			$(Name+' .change').append('<i>'+i+'</i>');
			$(Name+' .title').append('<a href="../admin/js/'+href+'">'+title+'</a>');
		}
		$(Name+' .change i').eq(0).addClass('cur');
	}
	$(Name+' div.changeDiv a').sGallery({//����ָ��㣬���ڰ���ͼƬ������
		titleObj:Name+' div.title a',
		thumbObj:Name+' .change i',
		thumbNowClass:Class
	});
	$(Name+" .title-bg").width(Width);
}

//����ͼ
jQuery.fn.LoadImage=function(scaling,width,height,loadpic){
    if(loadpic==null)loadpic="../images/msg_img/loading.gif";
return this.each(function(){
   var t=$(this);
   var src=$(this).attr("src")
   var img=new Image();
   img.src=src;
   //�Զ�����ͼƬ
   var autoScaling=function(){
    if(scaling){
     if(img.width>0 && img.height>0){ 
           if(img.width/img.height>=width/height){ 
               if(img.width>width){ 
                   t.width(width); 
                   t.height((img.height*width)/img.width); 
               }else{ 
                   t.width(img.width); 
                   t.height(img.height); 
               } 
           } 
           else{ 
               if(img.height>height){ 
                   t.height(height); 
                   t.width((img.width*height)/img.height); 
               }else{ 
                   t.width(img.width); 
                   t.height(img.height); 
               } 
           } 
       } 
    } 
   }
   //����ff�»��Զ���ȡ����ͼƬ
   if(img.complete){
    autoScaling();
      return;
   }
   $(this).attr("src","");
   var loading=$("<img alt=\"������...\" title=\"ͼƬ������...\" src=../admin/js//""+loadpic+"/" />");
  
   t.hide();
   t.after(loading);
   $(img).load(function(){
    autoScaling();
    loading.remove();
    t.attr("src",this.src);
    t.show();
	//$('.photo_prev a,.photo_next a').height($('#big-pic img').height());
   });
  });
}

//���Ϲ�������
function startmarquee(elementID,h,n,speed,delay){
 var t = null;
 var box = '#' + elementID;
 $(box).hover(function(){
  clearInterval(t);
  }, function(){
  t = setInterval(start,delay);
 }).trigger('mouseout');
 function start(){
  $(box).children('ul:first').animate({marginTop: '-='+h},speed,function(){
   $(this).css({marginTop:'0'}).find('li').slice(0,n).appendTo(this);
  })
 }
}

//TAB�л�
function SwapTab(name,title,content,Sub,cur){
  $(name+' '+title).mouseover(function(){
	  $(this).addClass(cur).siblings().removeClass(cur);
	  if(Sub) $(content+" > "+Sub).eq($(name+' '+title).index(this)).show().siblings().hide();
  });
}

//ͨ��select�˵�
$(function(){
	$(".mouseover").each(function(i){
		var type = $(this).attr('type'),height = parseInt($(this).attr('heights')),position=parseInt($(this).attr('position')),
			 navSub = $('.sub'+type+'_'+i);
		$(this).bind("mouseenter",function(){
			var offset =$(this).offset();
				if(navSub.css("display") == "none"){
					if(position==true){
						navSub.css({"position":"absolute","z-index":"100",left:offset.left,top:offset.top+height}).show();
					}else{
						navSub.show();
					}
				}
		}).bind("mouseleave",function(){
			navSub.hide();
		});
		navSub.bind({
			mouseenter:function(){
				navSub.show();
			},
			mouseleave:function(){
				navSub.hide();
			}
		})
	})
})

//�����Ӵ���

function taskMsg(obj){
	var msgbox = $("#msgbox"),
	    offset =$(obj).position(),
		w = ($(obj).width()+18)/2,
		s = $('#msgbox s');
	if(msgbox.css("display") == "none"){
		msgbox.slideDown("slow");
		msgbox.css("padding-left",offset.left+"px");
		s.css("left",w+"px")
	}else{
		msgbox.slideUp("slow");
	}
}

function openwin(url) {
    var a = document.createElement("a");
    a.setAttribute("href", url);
    a.setAttribute("target", "_blank");
    a.setAttribute("id", "openwin");
    document.body.appendChild(a);
    a.click();
}
